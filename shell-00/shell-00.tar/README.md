# Ex00

# Ex01
## Trocar o tamanho do arquivo
truncate -s 40 testShell01
## Trocar creation date
touch -t 202406012342.00 testShell00
